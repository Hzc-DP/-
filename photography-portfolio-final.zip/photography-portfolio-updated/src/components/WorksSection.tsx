import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './WorksSection.css';

// 作品类型定义
interface Work {
  id: string;
  title: string;
  category: string;
  role: string;
  description: string;
  equipment: string;
  thumbnail: string;
  videoUrl?: string;
  externalVideoLink?: string; // 新增：外部视频链接字段
}

// 作品分类
const categories = ["全部", "微电影", "宣传片", "电视广告", "短剧", "直播"];

const WorksSection = () => {
  const [works, setWorks] = useState<Work[]>([]);
  const [selectedCategory, setSelectedCategory] = useState("全部");
  const [selectedWork, setSelectedWork] = useState<Work | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editingWork, setEditingWork] = useState<Work | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [savedMessage, setSavedMessage] = useState('');
  const [showEditButton, setShowEditButton] = useState(false);

  // 加载作品数据
  useEffect(() => {
    const fetchWorks = async () => {
      try {
        const response = await fetch('/data/works.json');
        const data = await response.json();
        setWorks(data);
        setLoading(false);
      } catch (error) {
        console.error('加载作品数据失败:', error);
        setLoading(false);
      }
    };

    fetchWorks();
  }, []);

  // 根据选择的分类过滤作品
  const filteredWorks = selectedCategory === "全部" 
    ? works 
    : works.filter(work => work.category === selectedCategory);

  // 打开作品详情
  const openWorkDetail = (work: Work) => {
    setSelectedWork(work);
    document.body.style.overflow = 'hidden'; // 防止背景滚动
  };

  // 关闭作品详情
  const closeWorkDetail = () => {
    setSelectedWork(null);
    document.body.style.overflow = 'auto'; // 恢复背景滚动
  };

  // 打开编辑器
  const openEditor = (work?: Work) => {
    if (work) {
      setEditingWork({...work});
    } else {
      // 创建新作品
      setEditingWork({
        id: `work_${Date.now()}`,
        title: '新作品',
        category: categories[1],
        role: '',
        description: '',
        equipment: '',
        thumbnail: '/works/placeholder.jpg',
        videoUrl: '',
        externalVideoLink: ''
      });
    }
    setShowEditor(true);
    document.body.style.overflow = 'hidden';
  };

  // 关闭编辑器
  const closeEditor = () => {
    setShowEditor(false);
    setEditingWork(null);
    document.body.style.overflow = 'auto';
  };

  // 保存作品
  const saveWork = () => {
    if (!editingWork) return;

    const updatedWorks = editingWork.id 
      ? works.map(w => w.id === editingWork.id ? editingWork : w)
      : [...works, editingWork];
    
    setWorks(updatedWorks);
    
    // 在实际应用中，这里应该发送请求到服务器保存数据
    // 这里我们模拟保存到localStorage
    localStorage.setItem('works', JSON.stringify(updatedWorks));
    
    setSavedMessage('作品已保存！在实际部署中，您需要将更新后的数据上传到服务器。');
    setTimeout(() => setSavedMessage(''), 3000);
    
    closeEditor();
  };

  // 处理编辑器中的输入变化
  const handleInputChange = (field: string, value: string) => {
    if (!editingWork) return;
    setEditingWork({
      ...editingWork,
      [field]: value
    });
  };

  // 处理图片上传
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !editingWork) return;

    // 在实际应用中，这里应该上传图片到服务器
    // 这里我们使用FileReader在本地预览
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result && editingWork) {
        setEditingWork({
          ...editingWork,
          thumbnail: e.target.result as string
        });
      }
    };
    reader.readAsDataURL(file);
  };

  // 切换编辑模式
  const toggleEditMode = () => {
    setIsEditing(!isEditing);
  };

  if (loading) {
    return (
      <section id="作品" className="py-24 bg-black">
        <div className="container mx-auto px-6 flex justify-center items-center min-h-[50vh]">
          <div className="text-white text-xl">加载作品中...</div>
        </div>
      </section>
    );
  }

  return (
    <section 
      id="作品" 
      className="py-24 bg-black"
      onMouseEnter={() => setShowEditButton(true)}
      onMouseLeave={() => setShowEditButton(false)}
    >
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-center mb-12">
          <motion.h2 
            className="text-4xl font-bold text-white text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            视频作品
          </motion.h2>
          
          {/* 编辑模式切换按钮 - 高对比度设计 */}
          <motion.button
            className={`px-4 py-2 bg-white/30 hover:bg-white/50 text-white rounded-full transition-all duration-300 border border-white/60 shadow-lg ${
              showEditButton || isEditing ? 'opacity-100' : 'opacity-0'
            }`}
            onClick={toggleEditMode}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 0, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            {isEditing ? '完成编辑' : '编辑作品'}
          </motion.button>
        </div>

        {/* 分类过滤器 */}
        <motion.div 
          className="flex flex-wrap justify-center gap-4 mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {categories.map((category, index) => (
            <button
              key={index}
              className={`px-6 py-2 rounded-full text-sm transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-white text-black'
                  : 'bg-white/10 text-white hover:bg-white/20'
              }`}
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </button>
          ))}
        </motion.div>

        {/* 作品网格 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredWorks.map((work, index) => (
            <motion.div
              key={work.id}
              className="relative aspect-video overflow-hidden rounded-lg cursor-pointer group"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              onClick={() => isEditing ? openEditor(work) : openWorkDetail(work)}
            >
              {/* 缩略图 */}
              <div className="absolute inset-0 bg-black/30 group-hover:bg-black/50 transition-all duration-300 z-10"></div>
              <img 
                src={work.thumbnail} 
                alt={work.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                onError={(e) => {
                  // 图片加载失败时显示占位图
                  (e.target as HTMLImageElement).src = '/works/placeholder.jpg';
                }}
              />
              
              {/* 作品信息 */}
              <div className="absolute inset-0 flex flex-col justify-end p-6 z-20">
                <h3 className="text-xl font-bold text-white mb-1">{work.title}</h3>
                <p className="text-white/80 text-sm">{work.category} | {work.role}</p>
              </div>
              
              {/* 播放按钮 */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-30">
                <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center">
                  {isEditing ? (
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  ) : (
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M8 5V19L19 12L8 5Z" fill="white"/>
                    </svg>
                  )}
                </div>
              </div>
              
              {/* 编辑模式下显示编辑按钮 */}
              {isEditing && (
                <div className="absolute top-4 right-4 z-30">
                  <button 
                    className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center hover:bg-white/40 transition-colors duration-300"
                    onClick={(e) => {
                      e.stopPropagation();
                      openEditor(work);
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </button>
                </div>
              )}
            </motion.div>
          ))}
          
          {/* 编辑模式下显示添加按钮 */}
          {isEditing && (
            <motion.div
              className="relative aspect-video overflow-hidden rounded-lg cursor-pointer bg-white/5 hover:bg-white/10 border-2 border-dashed border-white/20 flex items-center justify-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              onClick={() => openEditor()}
            >
              <div className="text-white/60 flex flex-col items-center">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <span className="mt-2">添加作品</span>
              </div>
            </motion.div>
          )}
        </div>
        
        {/* 保存提示 */}
        {savedMessage && (
          <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50">
            {savedMessage}
          </div>
        )}
      </div>

      {/* 作品详情弹窗 */}
      <AnimatePresence>
        {selectedWork && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="relative bg-zinc-900 rounded-xl w-full max-w-5xl max-h-[90vh] overflow-y-auto"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {/* 关闭按钮 */}
              <button
                className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-black/70 transition-colors duration-300"
                onClick={closeWorkDetail}
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18 6L6 18M6 6L18 18" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>

              {/* 视频播放区域 */}
              <div className="aspect-video w-full bg-black">
                {selectedWork.externalVideoLink ? (
                  <div className="w-full h-full flex flex-col items-center justify-center">
                    <img 
                      src={selectedWork.thumbnail} 
                      alt={selectedWork.title} 
                      className="max-w-full max-h-[80%] object-contain"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/works/placeholder.jpg';
                      }}
                    />
                    <a 
                      href={selectedWork.externalVideoLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="mt-4 px-6 py-2 bg-white text-black rounded-full hover:bg-white/80 transition-colors duration-300 flex items-center"
                    >
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mr-2">
                        <path d="M8 5V19L19 12L8 5Z" fill="black"/>
                      </svg>
                      观看视频
                    </a>
                  </div>
                ) : selectedWork.videoUrl ? (
                  <video
                    className="w-full h-full object-contain"
                    controls
                    poster={selectedWork.thumbnail}
                  >
                    <source src={selectedWork.videoUrl} type="video/mp4" />
                    您的浏览器不支持视频播放。
                  </video>
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <img 
                      src={selectedWork.thumbnail} 
                      alt={selectedWork.title} 
                      className="max-w-full max-h-full object-contain"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/works/placeholder.jpg';
                      }}
                    />
                  </div>
                )}
              </div>

              {/* 作品信息 */}
              <div className="p-8">
                <h3 className="text-2xl font-bold text-white mb-2">{selectedWork.title}</h3>
                <p className="text-white/60 mb-6">{selectedWork.category} | {selectedWork.role}</p>
                
                <div className="mb-6">
                  <h4 className="text-lg font-medium text-white mb-2">工作内容</h4>
                  <p className="text-white/80">{selectedWork.description}</p>
                </div>
                
                <div>
                  <h4 className="text-lg font-medium text-white mb-2">使用设备</h4>
                  <p className="text-white/80 whitespace-pre-line">{selectedWork.equipment}</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 作品编辑弹窗 */}
      <AnimatePresence>
        {showEditor && editingWork && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="relative bg-zinc-900 rounded-xl w-full max-w-5xl max-h-[90vh] overflow-y-auto"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {/* 关闭按钮 */}
              <button
                className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-black/70 transition-colors duration-300"
                onClick={closeEditor}
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18 6L6 18M6 6L18 18" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>

              <div className="p-8">
                <h3 className="text-2xl font-bold text-white mb-6">{editingWork.id ? '编辑作品' : '添加作品'}</h3>
                
                {/* 缩略图上传 */}
                <div className="mb-6">
                  <label className="block text-white/80 text-sm font-bold mb-2">作品封面</label>
                  <div className="flex items-center gap-4">
                    <img src={editingWork.thumbnail} alt="Thumbnail" className="w-32 h-auto rounded-lg object-cover" />
                    <input 
                      type="file" 
                      accept="image/*" 
                      onChange={handleImageUpload} 
                      className="block w-full text-sm text-white/80 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-white/10 file:text-white hover:file:bg-white/20"
                    />
                  </div>
                </div>

                {/* 视频链接 */}
                <div className="mb-6">
                  <label className="block text-white/80 text-sm font-bold mb-2">视频链接 (本地视频或外部链接)</label>
                  <input 
                    type="text" 
                    value={editingWork.externalVideoLink || editingWork.videoUrl || ''} 
                    onChange={(e) => handleInputChange('externalVideoLink', e.target.value)} 
                    className="w-full p-3 rounded-lg bg-zinc-800 text-white border border-zinc-700 focus:outline-none focus:border-blue-500"
                    placeholder="输入视频链接，例如：https://www.youtube.com/watch?v=xxxxxx 或 /videos/my-video.mp4"
                  />
                </div>

                {/* 标题 */}
                <div className="mb-6">
                  <label className="block text-white/80 text-sm font-bold mb-2">标题</label>
                  <input 
                    type="text" 
                    value={editingWork.title} 
                    onChange={(e) => handleInputChange('title', e.target.value)} 
                    className="w-full p-3 rounded-lg bg-zinc-800 text-white border border-zinc-700 focus:outline-none focus:border-blue-500"
                  />
                </div>

                {/* 分类 */}
                <div className="mb-6">
                  <label className="block text-white/80 text-sm font-bold mb-2">分类</label>
                  <select 
                    value={editingWork.category} 
                    onChange={(e) => handleInputChange('category', e.target.value)} 
                    className="w-full p-3 rounded-lg bg-zinc-800 text-white border border-zinc-700 focus:outline-none focus:border-blue-500"
                  >
                    {categories.slice(1).map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                {/* 角色 */}
                <div className="mb-6">
                  <label className="block text-white/80 text-sm font-bold mb-2">角色</label>
                  <input 
                    type="text" 
                    value={editingWork.role} 
                    onChange={(e) => handleInputChange('role', e.target.value)} 
                    className="w-full p-3 rounded-lg bg-zinc-800 text-white border border-zinc-700 focus:outline-none focus:border-blue-500"
                  />
                </div>

                {/* 描述 */}
                <div className="mb-6">
                  <label className="block text-white/80 text-sm font-bold mb-2">工作内容</label>
                  <textarea 
                    value={editingWork.description} 
                    onChange={(e) => handleInputChange('description', e.target.value)} 
                    className="w-full p-3 rounded-lg bg-zinc-800 text-white border border-zinc-700 focus:outline-none focus:border-blue-500 h-32 resize-none"
                  ></textarea>
                </div>

                {/* 设备 */}
                <div className="mb-6">
                  <label className="block text-white/80 text-sm font-bold mb-2">使用设备</label>
                  <textarea 
                    value={editingWork.equipment} 
                    onChange={(e) => handleInputChange('equipment', e.target.value)} 
                    className="w-full p-3 rounded-lg bg-zinc-800 text-white border border-zinc-700 focus:outline-none focus:border-blue-500 h-24 resize-none"
                  ></textarea>
                </div>

                <div className="flex justify-end gap-4">
                  <button 
                    className="px-6 py-3 rounded-full bg-zinc-700 text-white hover:bg-zinc-600 transition-colors duration-300"
                    onClick={closeEditor}
                  >
                    取消
                  </button>
                  <button 
                    className="px-6 py-3 rounded-full bg-blue-600 text-white hover:bg-blue-500 transition-colors duration-300"
                    onClick={saveWork}
                  >
                    保存作品
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default WorksSection;


