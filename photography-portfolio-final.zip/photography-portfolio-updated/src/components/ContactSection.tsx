import { motion } from 'framer-motion';

const ContactSection = () => {
  const workExperiences = [
    {
      title: '资深摄影师 / 自由职业',
      duration: '2020年至今'
    },
    {
      title: '摄影指导 / XX影视制作公司',
      duration: '2018年 - 2020年'
    }
  ];

  return (
    <section id="联系" className="py-24 bg-black">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-4xl font-bold text-white mb-16 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          联系方式
        </motion.h2>

        <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* 联系信息 */}
          <motion.div 
            className="flex flex-col items-center space-y-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-2xl font-bold text-white mb-6 text-center">联系信息</h3>
            {[
              { icon: "wechat", label: "微信", value: "18928412864" },
              { icon: "qq", label: "QQ", value: "971071633" },
              { icon: "email", label: "邮箱", value: "971071633@qq.com" },
              { icon: "location", label: "坐标", value: "深圳" }
            ].map((item, index) => (
              <motion.div 
                key={index}
                className="flex flex-col items-center"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center mb-2">
                  {item.icon === "wechat" && (
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9.5 10C10.3284 10 11 9.32843 11 8.5C11 7.67157 10.3284 7 9.5 7C8.67157 7 8 7.67157 8 8.5C8 9.32843 8.67157 10 9.5 10Z" fill="white"/>
                      <path d="M14.5 10C15.3284 10 16 9.32843 16 8.5C16 7.67157 15.3284 7 14.5 7C13.6716 7 13 7.67157 13 8.5C13 9.32843 13.6716 10 14.5 10Z" fill="white"/>
                      <path d="M7.5 15C8.32843 15 9 14.3284 9 13.5C9 12.6716 8.32843 12 7.5 12C6.67157 12 6 12.6716 6 13.5C6 14.3284 6.67157 15 7.5 15Z" fill="white"/>
                      <path d="M16.5 15C17.3284 15 18 14.3284 18 13.5C18 12.6716 17.3284 12 16.5 12C15.6716 12 15 12.6716 15 13.5C15 14.3284 15.6716 15 16.5 15Z" fill="white"/>
                      <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 13.5997 2.37562 15.1116 3.04346 16.4525C3.22094 16.8088 3.28001 17.2161 3.17712 17.6006L2.58151 19.8267C2.32295 20.793 3.20701 21.677 4.17335 21.4185L6.39939 20.8229C6.78393 20.72 7.19121 20.7791 7.54753 20.9565C8.88837 21.6244 10.4003 22 12 22Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  )}
                  {item.icon === "qq" && (
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M12 6C9 6 7 8.5 7 11.5C7 13.5 7.5 15 8.5 16C9.5 17 10 17.5 10 18C10 18.5 9.5 19 9 19.5C8.5 20 8 20.5 8 21C8 21.5 8.5 22 9.5 22C10.5 22 11 21.5 11.5 21C12 20.5 12.5 20 13 20C13.5 20 14 20.5 14.5 21C15 21.5 15.5 22 16.5 22C17.5 22 18 21.5 18 21C18 20.5 17.5 20 17 19.5C16.5 19 16 18.5 16 18C16 17.5 16.5 17 17.5 16C18.5 15 19 13.5 19 11.5C19 8.5 17 6 14 6H12Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  )}
                  {item.icon === "email" && (
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M21 5.25L12 13.5L3 5.25" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M3 5.25H21V18C21 18.1989 20.921 18.3897 20.7803 18.5303C20.6397 18.671 20.4489 18.75 20.25 18.75H3.75C3.55109 18.75 3.36032 18.671 3.21967 18.5303C3.07902 18.3897 3 18.1989 3 18V5.25Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  )}
                  {item.icon === "location" && (
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 13.5C13.6569 13.5 15 12.1569 15 10.5C15 8.84315 13.6569 7.5 12 7.5C10.3431 7.5 9 8.84315 9 10.5C9 12.1569 10.3431 13.5 12 13.5Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M12 22.5C16 18.5 20 14.9183 20 10.5C20 6.08172 16.4183 2.5 12 2.5C7.58172 2.5 4 6.08172 4 10.5C4 14.9183 8 18.5 12 22.5Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  )}
                </div>
                <div>
                  <p className="text-white/60 text-sm">{item.label}</p>
                  <p className="text-white text-lg">{item.value}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* 工作经历 */}
          <motion.div
            className="flex flex-col items-center space-y-4"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h3 className="text-2xl font-bold text-white mb-6 text-center">工作经历</h3>
            {
              workExperiences.map((experience, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-sm rounded-lg p-4 w-full max-w-md text-center">
                  <h4 className="text-white font-medium">{experience.title}</h4>
                  <p className="text-white/70 text-sm">{experience.duration}</p>
                </div>
              ))
            }
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;


