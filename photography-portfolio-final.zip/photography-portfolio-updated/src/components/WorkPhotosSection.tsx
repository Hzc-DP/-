import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// 工作照类型定义
interface WorkPhoto {
  id: string;
  image: string;
  caption?: string;
}

// 示例工作照数据
const initialWorkPhotos: WorkPhoto[] = [
  {
    id: "photo1",
    image: "/work-photos/photo1.jpg",
    caption: "拍摄现场指导"
  },
  {
    id: "photo2",
    image: "/work-photos/photo2.jpg",
    caption: "调试设备"
  },
  {
    id: "photo3",
    image: "/work-photos/photo3.jpg",
    caption: "现场取景"
  },
  {
    id: "photo4",
    image: "/work-photos/photo4.jpg",
    caption: "团队协作"
  }
];

const WorkPhotosSection = () => {
  const [workPhotos, setWorkPhotos] = useState<WorkPhoto[]>([]);
  const [selectedPhoto, setSelectedPhoto] = useState<WorkPhoto | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editingPhoto, setEditingPhoto] = useState<WorkPhoto | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showEditButton, setShowEditButton] = useState(false);

  // 加载工作照数据
  useEffect(() => {
    // 在实际应用中，这里应该从服务器或本地存储加载数据
    // 这里我们使用示例数据
    const savedPhotos = localStorage.getItem('workPhotos');
    if (savedPhotos) {
      setWorkPhotos(JSON.parse(savedPhotos));
    } else {
      setWorkPhotos(initialWorkPhotos);
    }
    setLoading(false);
  }, []);

  // 打开照片详情
  const openPhotoDetail = (photo: WorkPhoto) => {
    setSelectedPhoto(photo);
    document.body.style.overflow = 'hidden';
  };

  // 关闭照片详情
  const closePhotoDetail = () => {
    setSelectedPhoto(null);
    document.body.style.overflow = 'auto';
  };

  // 打开编辑器
  const openEditor = (photo?: WorkPhoto) => {
    if (photo) {
      setEditingPhoto({...photo});
    } else {
      // 创建新照片
      setEditingPhoto({
        id: `photo_${Date.now()}`,
        image: '/work-photos/placeholder.jpg',
        caption: ''
      });
    }
    setShowEditor(true);
    document.body.style.overflow = 'hidden';
  };

  // 关闭编辑器
  const closeEditor = () => {
    setShowEditor(false);
    setEditingPhoto(null);
    document.body.style.overflow = 'auto';
  };

  // 保存照片
  const savePhoto = () => {
    if (!editingPhoto) return;

    const updatedPhotos = editingPhoto.id 
      ? workPhotos.map(p => p.id === editingPhoto.id ? editingPhoto : p)
      : [...workPhotos, editingPhoto];
    
    setWorkPhotos(updatedPhotos);
    
    // 保存到本地存储
    localStorage.setItem('workPhotos', JSON.stringify(updatedPhotos));
    
    closeEditor();
  };

  // 处理编辑器中的输入变化
  const handleInputChange = (field: string, value: string) => {
    if (!editingPhoto) return;
    setEditingPhoto({
      ...editingPhoto,
      [field]: value
    });
  };

  // 处理图片上传
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !editingPhoto) return;

    // 在实际应用中，这里应该上传图片到服务器
    // 这里我们使用FileReader在本地预览
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result && editingPhoto) {
        setEditingPhoto({
          ...editingPhoto,
          image: e.target.result as string
        });
      }
    };
    reader.readAsDataURL(file);
  };

  // 切换编辑模式
  const toggleEditMode = () => {
    setIsEditing(!isEditing);
  };

  if (loading) {
    return (
      <section id="工作照" className="py-24 bg-black">
        <div className="container mx-auto px-6 flex justify-center items-center min-h-[30vh]">
          <div className="text-white text-xl">加载工作照中...</div>
        </div>
      </section>
    );
  }

  return (
    <section 
      id="工作照" 
      className="py-24 bg-black"
      onMouseEnter={() => setShowEditButton(true)}
      onMouseLeave={() => setShowEditButton(false)}
    >
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-center mb-12">
          <motion.h2 
            className="text-4xl font-bold text-white text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            工作照
          </motion.h2>
          
          {/* 编辑模式切换按钮 - 高对比度设计 */}
          <motion.button
            className={`px-4 py-2 bg-white/20 hover:bg-white/40 text-white rounded-full transition-all duration-300 border border-white/40 shadow-glow ${
              showEditButton || isEditing ? 'opacity-70 hover:opacity-100' : 'opacity-0'
            }`}
            onClick={toggleEditMode}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 0, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            {isEditing ? '完成编辑' : '编辑照片'}
          </motion.button>
        </div>

        {/* 工作照网格 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {workPhotos.map((photo, index) => (
            <motion.div
              key={photo.id}
              className="relative aspect-square overflow-hidden rounded-lg cursor-pointer group"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              onClick={() => isEditing ? openEditor(photo) : openPhotoDetail(photo)}
            >
              {/* 照片 */}
              <div className="absolute inset-0 bg-black/30 group-hover:bg-black/50 transition-all duration-300 z-10"></div>
              <img 
                src={photo.image} 
                alt={photo.caption || '工作照'} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                onError={(e) => {
                  // 图片加载失败时显示占位图
                  (e.target as HTMLImageElement).src = '/work-photos/placeholder.jpg';
                }}
              />
              
              {/* 照片说明 */}
              {photo.caption && (
                <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-black/70 to-transparent z-20">
                  <p className="text-white text-sm">{photo.caption}</p>
                </div>
              )}
              
              {/* 编辑模式下显示编辑按钮 */}
              {isEditing && (
                <div className="absolute top-4 right-4 z-30">
                  <button 
                    className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center hover:bg-white/40 transition-colors duration-300"
                    onClick={(e) => {
                      e.stopPropagation();
                      openEditor(photo);
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </button>
                </div>
              )}
            </motion.div>
          ))}
          
          {/* 编辑模式下显示添加按钮 */}
          {isEditing && (
            <motion.div
              className="relative aspect-square overflow-hidden rounded-lg cursor-pointer bg-white/5 hover:bg-white/10 border-2 border-dashed border-white/20 flex items-center justify-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              onClick={() => openEditor()}
            >
              <div className="text-white/60 flex flex-col items-center">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <span className="mt-2">添加照片</span>
              </div>
            </motion.div>
          )}
        </div>
      </div>

      {/* 照片详情弹窗 */}
      <AnimatePresence>
        {selectedPhoto && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={closePhotoDetail}
          >
            <motion.div
              className="relative max-w-4xl max-h-[90vh]"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* 关闭按钮 */}
              <button
                className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-black/70 transition-colors duration-300"
                onClick={closePhotoDetail}
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18 6L6 18M6 6L18 18" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>

              {/* 照片 */}
              <img 
                src={selectedPhoto.image} 
                alt={selectedPhoto.caption || '工作照'} 
                className="max-w-full max-h-[80vh] object-contain rounded-lg"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/work-photos/placeholder.jpg';
                }}
              />
              
              {/* 照片说明 */}
              {selectedPhoto.caption && (
                <div className="mt-4 p-4 bg-zinc-900 rounded-lg">
                  <p className="text-white">{selectedPhoto.caption}</p>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 照片编辑弹窗 */}
      <AnimatePresence>
        {showEditor && editingPhoto && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="relative bg-zinc-900 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {/* 关闭按钮 */}
              <button
                className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-black/70 transition-colors duration-300"
                onClick={closeEditor}
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18 6L6 18M6 6L18 18" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>

              <div className="p-8">
                <h3 className="text-2xl font-bold text-white mb-6">
                  {editingPhoto.id ? '编辑照片' : '添加新照片'}
                </h3>
                
                <div className="space-y-6">
                  {/* 照片上传和预览 */}
                  <div>
                    <label className="block text-white mb-2">照片</label>
                    <div className="aspect-square bg-black/30 rounded-lg overflow-hidden relative">
                      <img 
                        src={editingPhoto.image} 
                        alt="照片预览" 
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = '/work-photos/placeholder.jpg';
                        }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <label className="px-4 py-2 bg-white/20 hover:bg-white/30 backdrop-blur-md text-white rounded-lg cursor-pointer transition-colors duration-300">
                          上传照片
                          <input 
                            type="file" 
                            accept="image/*" 
                            className="hidden" 
                            onChange={handleImageUpload}
                          />
                        </label>
                      </div>
                    </div>
                    <p className="text-white/60 text-sm mt-2">推荐尺寸：1080x1080，格式：JPG、PNG</p>
                  </div>
                  
                  {/* 照片说明 */}
                  <div>
                    <label className="block text-white mb-2">照片说明（可选）</label>
                    <input 
                      type="text" 
                      value={editingPhoto.caption || ''} 
                      onChange={(e) => handleInputChange('caption', e.target.value)}
                      placeholder="输入照片说明"
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-white/40"
                    />
                  </div>
                  
                  <div className="mt-8 flex justify-end">
                    <button 
                      className="px-6 py-2 bg-white text-black rounded-full hover:bg-white/80 transition-colors duration-300"
                      onClick={savePhoto}
                    >
                      保存照片
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default WorkPhotosSection;
