import { motion } from 'framer-motion';

const AboutSection = () => {
  const awards = [
    {
      title: '《遥视安息》纪录片',
      description: '“大学生新视频计划” 十佳作品'
    },
    {
      title: '《暮鼓晨钟》微电影',
      description: '“亚洲国际青年电影节” 摄影入围'
    },
    {
      title: '《哪里都是你》微电影',
      description: '“华年奖” 最佳灯光设计奖'
    },
    {
      title: '川影电视台',
      description: '优秀新闻工作者'
    },
    {
      title: '四川电影电视学院',
      description: '“电视台” 新闻部部长 (聘书)'
    },
    {
      title: '《遥视安息》《哪里都是你》',
      description: '“海南·陵水微视频大赛” 复赛'
    },
  ];

  return (
    <section id="关于我" className="py-24 bg-black">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-4xl font-bold text-white text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          关于我
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
          {/* 左侧：个人介绍 */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="text-2xl font-bold text-white mb-6">黄志聪</h3>
            <p className="text-white/80 mb-6 leading-relaxed">
              我是一名专业摄影师和导演，专注于微电影、宣传片和广告拍摄。拥有多年行业经验，
              擅长通过镜头语言讲述引人入胜的故事，捕捉独特瞬间。
            </p>
            <p className="text-white/80 mb-6 leading-relaxed">
              我的作品风格注重视觉美感与情感表达的平衡，善于运用光影、构图和色彩创造独特的视觉体验。
              无论是商业项目还是艺术创作，我都致力于将客户的理念转化为令人难忘的视觉作品。
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg px-5 py-3">
                <h4 className="text-white font-medium mb-1">专业领域</h4>
                <p className="text-white/70 text-sm">微电影、宣传片、广告、短剧</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg px-5 py-3">
                <h4 className="text-white font-medium mb-1">技术特长</h4>
                <p className="text-white/70 text-sm">摄影指导、灯光设计、后期调色</p>
              </div>
            </div>
          </motion.div>
          
          {/* 右侧：获奖 */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-2xl font-bold text-white mb-6 text-center">获奖</h3>
            
            <div className="space-y-6 flex flex-col items-center">
              {awards.map((award, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-sm rounded-lg p-4 w-full max-w-md text-center">
                  <h4 className="text-white font-medium mb-1">{award.title}</h4>
                  <p className="text-white/70 text-sm">{award.description}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;


