import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileHover, setProfileHover] = useState(false);

  // 监听滚动事件
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  return (
    <header className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${scrolled ? 'bg-black/80 backdrop-blur-md py-4' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-center">
          {/* 左侧：Logo和标题 */}
          <div className="flex items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="text-white text-2xl font-bold"
            >
              黄志聪作品集
            </motion.div>
          </div>

          {/* 右侧：个人照片窗口 */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="relative"
            onMouseEnter={() => setProfileHover(true)}
            onMouseLeave={() => setProfileHover(false)}
          >
            <div className={`w-12 h-12 rounded-full overflow-hidden border-2 transition-all duration-300 ${profileHover ? 'border-white scale-110' : 'border-white/50'}`}>
              <img 
                src="/assets/images/profile.jpg" 
                alt="黄志聪" 
                className="w-full h-full object-cover"
                onError={(e) => {
                  // 图片加载失败时显示占位图
                  (e.target as HTMLImageElement).src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100%25" height="100%25" viewBox="0 0 100 100"%3E%3Crect width="100" height="100" fill="%23333"%3E%3C/rect%3E%3Ctext x="50%25" y="50%25" dominant-baseline="middle" text-anchor="middle" font-family="Arial" font-size="14" fill="%23fff"%3E个人照%3C/text%3E%3C/svg%3E';
                }}
              />
            </div>
            
            {/* 悬停时显示的扩展信息 */}
            <motion.div 
              className="absolute top-full right-0 mt-2 bg-black/80 backdrop-blur-md rounded-lg p-4 w-64 shadow-xl"
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ 
                opacity: profileHover ? 1 : 0,
                y: profileHover ? 0 : -10,
                scale: profileHover ? 1 : 0.95
              }}
              transition={{ duration: 0.2 }}
              style={{ pointerEvents: profileHover ? 'auto' : 'none' }}
            >
              <div className="flex items-center space-x-3 mb-3">
                <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white/50">
                  <img 
                    src="/assets/images/profile.jpg" 
                    alt="黄志聪" 
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100%25" height="100%25" viewBox="0 0 100 100"%3E%3Crect width="100" height="100" fill="%23333"%3E%3C/rect%3E%3Ctext x="50%25" y="50%25" dominant-baseline="middle" text-anchor="middle" font-family="Arial" font-size="14" fill="%23fff"%3E个人照%3C/text%3E%3C/svg%3E';
                    }}
                  />
                </div>
                <div>
                  <h3 className="text-white font-medium">黄志聪</h3>
                  <p className="text-white/70 text-sm">摄影师 / 导演</p>
                </div>
              </div>
              <div className="text-white/80 text-sm">
                专注于微电影、宣传片和广告拍摄的专业摄影师，擅长通过镜头语言讲述引人入胜的故事。
              </div>
              <div className="mt-3 flex justify-end">
                <a href="#关于我" className="text-white/60 text-sm hover:text-white transition-colors duration-300">了解更多 →</a>
              </div>
            </motion.div>
          </motion.div>

          {/* 中间：导航菜单 */}
          <nav className="hidden md:block absolute left-1/2 transform -translate-x-1/2">
            <motion.ul
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex space-x-8"
            >
              <li>
                <a href="#作品" className="text-white hover:text-white/70 transition-colors duration-300">作品</a>
              </li>
              <li>
                <a href="#工作照" className="text-white hover:text-white/70 transition-colors duration-300">工作照</a>
              </li>
              <li>
                <a href="#关于我" className="text-white hover:text-white/70 transition-colors duration-300">关于我</a>
              </li>
              <li>
                <a href="#联系" className="text-white hover:text-white/70 transition-colors duration-300">联系</a>
              </li>
            </motion.ul>
          </nav>

          {/* 移动端菜单按钮 */}
          <div className="md:hidden">
            <button
              className="text-white focus:outline-none"
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? (
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              ) : (
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 6H20M4 12H20M4 18H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 移动端菜单 */}
      <motion.div
        className="md:hidden"
        initial={{ height: 0, opacity: 0 }}
        animate={{ 
          height: menuOpen ? 'auto' : 0,
          opacity: menuOpen ? 1 : 0
        }}
        transition={{ duration: 0.3 }}
        style={{ overflow: 'hidden' }}
      >
        <div className="container mx-auto px-6 py-4 bg-black/90 backdrop-blur-md">
          <ul className="space-y-4">
            <li>
              <a 
                href="#作品" 
                className="text-white block py-2"
                onClick={() => setMenuOpen(false)}
              >
                作品
              </a>
            </li>
            <li>
              <a 
                href="#工作照" 
                className="text-white block py-2"
                onClick={() => setMenuOpen(false)}
              >
                工作照
              </a>
            </li>
            <li>
              <a 
                href="#关于我" 
                className="text-white block py-2"
                onClick={() => setMenuOpen(false)}
              >
                关于我
              </a>
            </li>
            <li>
              <a 
                href="#联系" 
                className="text-white block py-2"
                onClick={() => setMenuOpen(false)}
              >
                联系
              </a>
            </li>
          </ul>
        </div>
      </motion.div>
    </header>
  );
};

export default Header;


