import { useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import WorksSection from './components/WorksSection';
import WorkPhotosSection from './components/WorkPhotosSection';
import AboutSection from './components/AboutSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import './App.css';

function App() {
  useEffect(() => {
    // 平滑滚动设置
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e: Event) {
        e.preventDefault();
        const href = (e.currentTarget as HTMLAnchorElement).getAttribute('href') || '';
        const target = document.querySelector(href);
        if (target) {
          target.scrollIntoView({
            behavior: 'smooth'
          });
        }
      });
    });

    // 加载动画
    const loader = document.getElementById('loader');
    if (loader) {
      setTimeout(() => {
        loader.classList.add('fade-out');
        setTimeout(() => {
          loader.style.display = 'none';
        }, 500);
      }, 1000);
    }

    return () => {
      document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.removeEventListener('click', function (e) {
          e.preventDefault();
        });
      });
    };
  }, []);

  return (
    <>
      <div id="loader" className="fixed inset-0 bg-black z-50 flex items-center justify-center">
        <div className="text-white text-2xl">黄志聪摄影作品集</div>
      </div>
      
      <Header />
      <Hero />
      <WorksSection />
      <WorkPhotosSection />
      <AboutSection />
      <ContactSection />
      <Footer />
    </>
  );
}

export default App;
