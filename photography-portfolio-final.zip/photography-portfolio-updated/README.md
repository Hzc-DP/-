# 黄志聪摄影作品集网站

## 项目说明

这是一个基于React和Framer Motion开发的摄影作品展示网站，设计风格简约大气，类似Apple的设计语言，并且拥有流畅的动画效果。网站主要展示黄志聪的视频作品，包括微电影、宣传片、TVC等。

## 技术栈

- React
- TypeScript
- Tailwind CSS
- Framer Motion (动画库)

## 项目结构

```
photography-portfolio/
├── public/
│   ├── assets/
│   │   └── images/       # 存放图片资源
│   ├── index.html        # HTML入口文件
│   └── favicon.ico       # 网站图标
├── src/
│   ├── components/       # React组件
│   │   ├── Header.tsx    # 导航栏组件
│   │   ├── Hero.tsx      # 首页主视觉组件
│   │   ├── WorksSection.tsx  # 作品展示区组件
│   │   ├── AboutSection.tsx  # 关于我组件
│   │   ├── ContactSection.tsx # 联系方式组件
│   │   └── Footer.tsx    # 页脚组件
│   ├── App.tsx           # 应用主组件
│   ├── index.css         # 全局样式
│   └── main.tsx          # 应用入口
├── tailwind.config.js    # Tailwind配置
└── package.json          # 项目依赖
```

## 功能特点

1. **简约大气的设计风格**：参考Apple官网的设计语言，采用大量留白和精致细节
2. **流畅的动画效果**：使用Framer Motion实现平滑的过渡和交互动画
3. **响应式设计**：适配桌面端、平板端和移动端
4. **作品展示**：按分类展示视频作品，点击可查看详情和播放视频
5. **联系表单**：提供联系方式和消息发送功能

## 动画效果

网站包含以下动画效果：

1. **滚动动画**：元素随滚动优雅呈现
2. **悬停效果**：图片和按钮的精致悬停反馈
3. **页面过渡**：平滑的页面切换效果
4. **视差滚动**：背景和内容的视差效果

## 部署说明

1. 确保已安装Node.js和npm
2. 安装依赖：`npm install`
3. 开发模式运行：`npm run dev`
4. 构建生产版本：`npm run build`
5. 部署dist目录到任意静态网站托管服务

## 后续扩展建议

1. 添加实际视频链接和剧照
2. 集成CMS系统方便内容更新
3. 添加多语言支持
4. 实现作品筛选和搜索功能
5. 添加作品详情页面
